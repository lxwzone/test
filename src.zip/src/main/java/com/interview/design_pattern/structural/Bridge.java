package com.interview.design_pattern.structural;

//Decouples abstraction from implementation so the two can vary independently.
//👉 Good for platforms where abstraction and implementation need to evolve
public class Bridge {

}
interface Implementor {
    void operationImpl();
}
class ConcreteImpl implements Implementor {
    public void operationImpl() { System.out.println("Implementation"); }
}
abstract class Abstraction {
    protected Implementor impl;
    public Abstraction(Implementor impl) { this.impl = impl; }
    abstract void operation();
}
class RefinedAbstraction extends Abstraction {
    public RefinedAbstraction(Implementor impl) { super(impl); }
    public void operation() { impl.operationImpl(); }
}
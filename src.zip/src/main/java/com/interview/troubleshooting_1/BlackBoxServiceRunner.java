package com.interview.troubleshooting_1;

public class BlackBoxServiceRunner {

    public static void main(String[] args) {
        int numberOfThreads = 10000;
        for (int i = 0; i < numberOfThreads; i++) {
            Thread thread = new Thread(new BlackBoxService(i));
            thread.start();
        }
    }
}

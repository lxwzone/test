package com.interview.design_pattern.behavioral;

import java.util.ArrayList;
import java.util.List;

//When one object changes state, its dependents are notified automatically.
//👉 Used in event systems, GUI toolkits.
public interface Observer {
    void update(String message);
}
class Subject {
    private List<Observer> observers = new ArrayList<>();
    public void attach(Observer o) { observers.add(o); }
    public void notifyObservers(String message) {
        for (Observer o : observers) o.update(message);
    }
}
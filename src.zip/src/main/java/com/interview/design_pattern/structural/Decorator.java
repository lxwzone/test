package com.interview.design_pattern.structural;

//Adds responsibilities to objects dynamically without altering the class.
//👉 Used in Java I/O classes (BufferedReader, InputStream etc.)

public class Decorator implements Component {
    protected Component component;
    public Decorator(Component component) { this.component = component; }
    public void operation() {
        component.operation();
        System.out.println("Decorator added behavior");
    }
}

interface Component {
    void operation();
}
class ConcreteComponent implements Component {
    public void operation() { System.out.println("ConcreteComponent"); }
}
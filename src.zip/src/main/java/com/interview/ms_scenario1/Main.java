package com.interview.ms_scenario1;

public class Main {


    public static void main(String[] args) {
        //muserver.io
        //Order Service - Manages customer orders.
        //Inventory Service - Manages product stock levels.

        //Use Case 1: Place an order, check inventory if there is enough stock and save the stock into DB if the stock is available.
        //after saving the order , send an email to notify the person who made the order. However because email system is down, the order should still be saved.
        //But when the email system is back up, the email should be sent.
        //What is your test strategy to verify it works as expected?
    }
}

package com.interview.design_pattern.behavioral;

//Defines an object that encapsulates how a set of objects interact.
//👉 Reduces direct dependencies.

public interface Mediator {
    void send(String message, Colleague colleague);
}

abstract class Colleague {
    protected Mediator mediator;
    public Colleague(Mediator mediator) { this.mediator = mediator; }
}

class ConcreteMediator implements Mediator {
    private Colleague1 c1;
    private Colleague2 c2;
    public void setColleagues(Colleague1 c1, Colleague2 c2) {
        this.c1 = c1;
        this.c2 = c2;
    }
    public void send(String message, Colleague colleague) {
        if (colleague == c1) c2.receive(message);
        else c1.receive(message);
    }
}

class Colleague1 extends Colleague {
    public Colleague1(Mediator m) { super(m); }
    public void send(String msg) { mediator.send(msg, this); }
    public void receive(String msg) { System.out.println("C1 received: " + msg); }
}

class Colleague2 extends Colleague {
    public Colleague2(Mediator m) { super(m); }
    public void send(String msg) { mediator.send(msg, this); }
    public void receive(String msg) { System.out.println("C2 received: " + msg); }
}
package com.interview.design_pattern.behavioral;
//Encapsulates a request as an object.
//👉 Useful for undo/redo functionality.

interface Command {
    void execute();
}
class Receiver {
    void action() { System.out.println("Action performed"); }
}
class ConcreteCommand implements Command {
    private Receiver receiver;
    public ConcreteCommand(Receiver receiver) { this.receiver = receiver; }
    public void execute() { receiver.action(); }
}
class Invoker {
    private Command command;
    public void setCommand(Command command) { this.command = command; }
    public void run() { command.execute(); }
}
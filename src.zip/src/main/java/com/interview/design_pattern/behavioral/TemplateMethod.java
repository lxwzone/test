package com.interview.design_pattern.behavioral;

//Defines the skeleton of an algorithm, deferring steps to subclasses.
//👉 Used for code reuse in superclass.

public class TemplateMethod {

}

abstract class AbstractClass {
    public void templateMethod() {
        stepOne();
        stepTwo();
    }
    abstract void stepOne();
    abstract void stepTwo();
}
class ConcreteClass extends AbstractClass {
    void stepOne() { System.out.println("Step One"); }
    void stepTwo() { System.out.println("Step Two"); }
}

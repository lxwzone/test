package com.interview.design_pattern.structural;
//Converts one interface to another expected by the client.
//👉 Used to integrate old APIs with new ones.
public class Adapter {
    private Adaptee adaptee = new Adaptee();
    public void request() { adaptee.specificRequest(); }
}

interface Target {
    void request();
}
class Adaptee {
    void specificRequest() { System.out.println("Specific request"); }
}

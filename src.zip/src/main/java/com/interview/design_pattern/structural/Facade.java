package com.interview.design_pattern.structural;

//Provides a simplified interface to a larger body of code.
//👉 Helps hide complex subsystem logic.
public class Facade {
    private SubsystemA a = new SubsystemA();
    private SubsystemB b = new SubsystemB();
    public void operation() {
        a.operationA();
        b.operationB();
    }
}

class SubsystemA {
    void operationA() {
        System.out.println("A");
    }
}
class SubsystemB {
    void operationB() {
        System.out.println("B");
    }
}

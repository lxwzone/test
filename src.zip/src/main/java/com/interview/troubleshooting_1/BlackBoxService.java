package com.interview.troubleshooting_1;

import java.util.Random;

public class BlackBoxService implements Runnable {

    private final int threadId;
    private static final Random random = new Random();

    public BlackBoxService(int threadId) {
        this.threadId = threadId;
    }

    @Override
    public void run() {
//        System.out.println("Thread " + threadId + " started.");
        try {
            // Simulate random hanging
            if (random.nextInt(10) == 0) {
//                System.out.println("Thread " + threadId + " is stuck.");
                Thread.sleep(Long.MAX_VALUE);
            } else {
                // Simulate normal work
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
//            System.out.println("Thread " + threadId + " was interrupted.");
        }
//        System.out.println("Thread " + threadId + " finished.");
    }


}

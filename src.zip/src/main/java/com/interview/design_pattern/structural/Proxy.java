package com.interview.design_pattern.structural;
//Provides a surrogate or placeholder for another object.
//👉 Used for lazy loading, access control, logging.
public class Proxy {
}
interface Service {
    void execute();
}
class RealService implements Service {
    public void execute() { System.out.println("Executing service"); }
}
class ProxyService implements Service {
    private RealService realService = new RealService();
    public void execute() {
        System.out.println("Proxy check");
        realService.execute();
    }
}
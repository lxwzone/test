package com.interview.troubleshooting_2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class BankAccount {
    private int balance = 100;

    public void withdraw(int amount) {
        if (balance >= amount) {
            System.out.println(Thread.currentThread().getName() + " is withdrawing " + amount);
            try {
                Thread.sleep(50); // Simulate delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " completed withdrawal. Remaining balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " insufficient funds!");
        }
    }
}


public class RaceConditionDemo {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Three users trying to withdraw money at the same time
        for (int i = 0; i < 3; i++) {
            executor.execute(() -> account.withdraw(50));
        }

        executor.shutdown();
    }
}
package com.interview.problem_finiding_1;

import java.io.File;

public class ArchiveService {


    public void backup(File originalFile) {
        // Backup the file
        File newIdenticalFile = copyToNewFile(originalFile);

        // Upload the file to a remote server
        uploadFile(newIdenticalFile);

        // Delete the temporary file after uploading
        newIdenticalFile.delete();

        // What problem(s) do you see in this code?

    }

    private void uploadFile(File newFile) {
        // Upload the file to a remote server
    }

    private File copyToNewFile(File fileToBackup) {
        // Copy the file to a new location
        return null;
    }


}

package com.interview.design_pattern.creational;

//Creates new objects by copying an existing object (cloning).
//👉 Useful when object creation is expensive.

public class Prototype implements Cloneable {
    public Prototype clone() throws CloneNotSupportedException {
        return (Prototype) super.clone();
    }
}


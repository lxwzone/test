package com.interview.test_strategy_1;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.List;
import java.util.Set;

public class TradeBookingService {
    private static final Set<String> SUPPORTED_INSTRUMENTS = Set.of("STOCK", "BOND");
    private static final Set<Currency> SUPPORTED_CURRENCIES = Set.of(
            Currency.getInstance("USD"),
            Currency.getInstance("GBP")
    );
    private static final List<String> APPROVED_COUNTERPARTIES = Arrays.asList("BankA", "BankB", "BankC");

    public static boolean isValidBusinessDay(LocalDate date) {
        if (date == null) return false;
        return !(date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY);
    }

    public void bookTrade(Trade trade) {
        if (isValidTrade(trade)) {

            if(trade.getInstrumentType().equals("STOCK")) {
                //callStockTradeService(trade);
                System.out.println("Stock trade booked successfully: " + trade);
            } else if(trade.getInstrumentType().equals("BOND")) {
                //callBondTradeService(trade);
                System.out.println("Bond trade booked successfully: " + trade);
            }
        } else {
            System.out.println("Invalid trade: " + trade);
        }
    }

    public static boolean isValidTrade(Trade trade) {
        if (trade == null) return false;
        // Trade Date must be a business day
        if (!isValidBusinessDay(trade.getTradeDate())) return false;
        // Settlement Date must be after Trade Date and a business day
        if (trade.getSettlementDate().isBefore(trade.getTradeDate()) || !isValidBusinessDay(trade.getSettlementDate())) return false;
        // Counterparty must be approved
        if (!APPROVED_COUNTERPARTIES.contains(trade.getCounterparty())) return false;
        // Notional Amount must be within limits (e.g., min $1,000, max $10,000,000)
        if (trade.getNotionalAmount() < 1000 || trade.getNotionalAmount() > 10_000_000) return false;
        // Currency must be supported
        if (!SUPPORTED_CURRENCIES.contains(trade.getCurrency())) return false;
        // Instrument Type must be valid
        if (!SUPPORTED_INSTRUMENTS.contains(trade.getInstrumentType())) return false;

        return true; // If all checks pass, trade is valid
    }
}

class Trade {
    private LocalDate tradeDate;
    private LocalDate settlementDate;
    private String counterparty;
    private double notionalAmount;
    private Currency currency;
    private String instrumentType;

    public Trade(LocalDate tradeDate, LocalDate settlementDate, String counterparty,
                 double notionalAmount, Currency currency, String instrumentType) {
        this.tradeDate = tradeDate;
        this.settlementDate = settlementDate;
        this.counterparty = counterparty;
        this.notionalAmount = notionalAmount;
        this.currency = currency;
        this.instrumentType = instrumentType;
    }

    public LocalDate getTradeDate() { return tradeDate; }
    public LocalDate getSettlementDate() { return settlementDate; }
    public String getCounterparty() { return counterparty; }
    public double getNotionalAmount() { return notionalAmount; }
    public Currency getCurrency() { return currency; }
    public String getInstrumentType() { return instrumentType; }
}
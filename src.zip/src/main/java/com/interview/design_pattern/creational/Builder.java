package com.interview.design_pattern.creational;

//Separates the construction of a complex object from its representation.
//👉 Used for constructing objects with many optional parameters.

public class Builder {

}

class ProductBuilder {
    private String partA;
    private String partB;
    public ProductBuilder setPartA(String partA) {
        this.partA = partA;
        return this;
    }
    public ProductBuilder setPartB(String partB) {
        this.partB = partB;
        return this;
    }
    public ProductX build() {
        return new ProductX(partA, partB);
    }
}
class ProductX {
    String partA, partB;
    public ProductX(String partA, String partB) {
        this.partA = partA;
        this.partB = partB;
    }
}

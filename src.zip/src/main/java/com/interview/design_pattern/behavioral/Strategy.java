package com.interview.design_pattern.behavioral;
//Enables selecting an algorithm at runtime.
//👉 Used in sorting or compression strategy contexts.
public interface Strategy {
    int doOperation(int a, int b);
}
class AddStrategy implements Strategy {
    public int doOperation(int a, int b) { return a + b; }
}
class Context {
    private Strategy strategy;
    public Context(Strategy strategy) { this.strategy = strategy; }
    public int execute(int a, int b) { return strategy.doOperation(a, b); }
}

package com.interview.design_pattern.behavioral;

import java.util.Arrays;
import java.util.Iterator;

//Provides a way to access elements of a collection sequentially.
//👉 Built into Java Collections.
public class IteratorPattern {
}

class NameRepository {
    String[] names = {"Alice", "Bob"};
    public Iterator<String> getIterator() {
        return Arrays.asList(names).iterator();
    }
}
package com.interview.code_improvement;

import com.google.cloud.bigquery.*;

import java.io.File;

public class CloudService {


    public void saveIntoCloudStorage(File file) {
        // Save data into cloud storage
//        Storage
    }

    public void query(String query) {
        BigQuery bigquery = BigQueryOptions.getDefaultInstance().getService();
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
                .build();
        JobId jobId = JobId.newBuilder().build();
        Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());

    }

}

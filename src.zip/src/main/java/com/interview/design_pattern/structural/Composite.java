package com.interview.design_pattern.structural;

import java.util.ArrayList;
import java.util.List;

//Composite
//Treats individual objects and compositions uniformly.
//👉 Used for tree-like structures (e.g., UI elements).
public class Composite implements ComponentC {
    private List<ComponentC> children = new ArrayList<>();
    public void add(ComponentC c) { children.add(c); }
    public void operation() {
        for (ComponentC child : children) {
            child.operation();
        }
    }
}

interface ComponentC {
    void operation();
}
class Leaf implements ComponentC {
    public void operation() { System.out.println("Leaf"); }
}
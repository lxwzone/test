package com.interview.design_pattern.structural;

import java.util.HashMap;
import java.util.Map;

//Reduces memory usage by sharing objects that are similar.
//👉 Used in game engines, text rendering.
public class Flyweight {
    private final String state;
    public Flyweight(String state) { this.state = state; }
    public void operation() { System.out.println("State: " + state); }
}
class FlyweightFactory {
    private Map<String, Flyweight> pool = new HashMap<>();
    public Flyweight getFlyweight(String key) {
        return pool.computeIfAbsent(key, Flyweight::new);
    }
}
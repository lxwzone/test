package com.interview.crytography.hash;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Sha256Example {

    public static void main(String[] args) {
        String input = "hello world";
        String hash = sha256(input);
        System.out.println("SHA-256 hash: " + hash);
    }

    public static String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b); // mask with 0xff to handle negative bytes
            if (hex.length() == 1) hexString.append('0'); // pad with zero if needed
            hexString.append(hex);
        }
        return hexString.toString();
    }
}

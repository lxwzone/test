package com.interview.design_pattern.behavioral;
//Allows an object to alter its behavior when its internal state changes.
//👉 Used in UI, workflow engines.
public interface State {
    void handle();
}
class ContextState {
    private State state;
    public void setState(State state) { this.state = state; }
    public void request() { state.handle(); }
}
class ConcreteStateA implements State {
    public void handle() { System.out.println("Handling A"); }
}

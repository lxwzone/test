package com.interview.design_pattern.behavioral;

//Passes request along a chain of handlers.
//👉 Used in request processing pipelines.
public class ChainOfResponsibility {

}

abstract class Handler {
    protected Handler next;
    public void setNext(Handler next) { this.next = next; }
    public abstract void handle(String request);
}
class ConcreteHandler extends Handler {
    public void handle(String request) {
        if (request.equals("process")) System.out.println("Processed");
        else if (next != null) next.handle(request);
    }
}
